sudo ./advanstAutoGrinder
